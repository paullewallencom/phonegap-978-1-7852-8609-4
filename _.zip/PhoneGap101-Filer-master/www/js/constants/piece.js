module.exports = {
    PIECETYPE: "Piece",
    TEXTPIECETYPE: "TextPiece"
};
